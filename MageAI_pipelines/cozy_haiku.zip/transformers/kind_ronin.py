if 'transformer' not in globals():
    from mage_ai.data_preparation.decorators import transformer
if 'test' not in globals():
    from mage_ai.data_preparation.decorators import test


@transformer
def transform(data, *args, **kwargs):
    """
    Template code for a transformer block.

    Add more parameters to this function if this block has multiple parent blocks.
    There should be one parameter for each output variable from each parent block.

    Args:
        data: The output from the upstream parent block
        args: The output from any additional upstream blocks (if applicable)

    Returns:
        Anything (e.g. data frame, dictionary, array, int, str, etc.)
    """
    # Specify your transformation logic here

    objects = data.get("objects", [])
    transformed_objects = []

    for i, obj in enumerate(objects):
        position = obj.get("position", {})
        
        # Extract current coordinates
        x = position.get("x", 0.0)
        y = position.get("y", 0.0)
        z = position.get("z", 0.0)

        if i == 0:
            z -= 1
        else:
            z += 1

        transformed_objects.append({
            "name": obj["name"],
            "position": {
                "x": x,
                "y": y,
                "z": z
            }
        })

    return {"objects": transformed_objects}


@test
def test_output(output, *args) -> None:
    """
    Template code for testing the output of the block.
    """
    assert output is not None, 'The output is undefined'

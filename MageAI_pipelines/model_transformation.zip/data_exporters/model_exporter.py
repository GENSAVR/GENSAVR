import trimesh
from io import StringIO

if 'data_exporter' not in globals():
    from mage_ai.data_preparation.decorators import data_exporter


@data_exporter
def export_data(data, *args, **kwargs):
    """
    Exports data to some source.

    Args:
        data: The output from the upstream parent block
        args: The output from any additional upstream blocks (if applicable)

    Output (optional):
        Optionally return any object and it'll be logged and
        displayed when inspecting the block run.
    """
    mesh_io = StringIO(data)

    mesh = trimesh.load(mesh_io, file_type='obj')

    output_path = f"/home/src/xr50/objects/{kwargs.get('file')['name']}"

    mesh.export(output_path)

    print(output_path)

